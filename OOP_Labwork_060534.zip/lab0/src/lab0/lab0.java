/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab0;

/**
 *
 * @author badi
 */
public class lab0 implements OnClickListener {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }

    public void test(){
    lab0 l = new lab0();
    
    l.onClick();

    }
    @Override
    public void onClick() {
        
    }
    
}
